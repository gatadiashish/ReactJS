/* eslint-disable react/react-in-jsx-scope */
import { useRef, useState, useCallback } from "react";

import Places from "./components/Places.jsx";
import Modal from "./components/Modal.jsx";
import DeleteConfirmation from "./components/DeleteConfirmation.jsx";
import logoImg from "./assets/logo.png";
import AvailablePlaces from "./components/AvailablePlaces.jsx";
import { fetchPlaces, updateSelectedPlaces } from "./http.js";
import Error from "./components/Error.jsx";
import { useFetch } from "./hooks/useFetch.js";

function App() {
  const selectedPlace = useRef();
  // const [isFetching, setIsFetching] = useState(false);
  // const [errorFetchSelectPlaces, setErrorFetchSelectPlaces] = useState();
  // const [userPlaces, setUserPlaces] = useState([]);
  const [errorSelectPlaces, setErrorSelectPlaces] = useState();
  const [modalIsOpen, setModalIsOpen] = useState(false);

  function handleStartRemovePlace(place) {
    setModalIsOpen(true);
    selectedPlace.current = place;
  }

  function handleStopRemovePlace() {
    setModalIsOpen(false);
  }

  const {
    fetchedData: userPlaces,
    isLoading: isFetching,
    error: errorFetchSelectPlaces,
    setFetchedData: setUserPlaces,
  } = useFetch(
    useCallback(() => fetchPlaces("http://localhost:3000/user-places"), [])
  );

  // useEffect(() => {
  //   async function fetchUserPlaces() {
  //     try {
  //       setIsFetching(true);
  //       console.log(
  //         "user Places inside useEffect are >>>>>>>>>>>>>>>>>>> : ",
  //         userPlaces
  //       );
  //       const data = await fetchPlaces("http://localhost:3000/user-places");
  //       setUserPlaces(data || []);
  //     } catch (error) {
  //       console.error("Error fetching user places:", error);
  //       setErrorFetchSelectPlaces({ message: "Failed to fetch user places!" });
  //     } finally {
  //       setIsFetching(false);
  //     }
  //   }
  //   fetchUserPlaces();
  // }, []);

  async function handleSelectPlace(selectedPlace) {
    setUserPlaces((prevPickedPlaces) => {
      if (!prevPickedPlaces) {
        prevPickedPlaces = [];
      }
      if (prevPickedPlaces.some((place) => place.id === selectedPlace.id)) {
        return prevPickedPlaces;
      }
      return [selectedPlace, ...prevPickedPlaces];
    });
    try {
      await updateSelectedPlaces([selectedPlace, ...userPlaces]);
    } catch (error) {
      setUserPlaces(userPlaces);
      console.error("Error updating selected places:", error);
      setErrorSelectPlaces({
        message: error.message || "Failed to update the place!",
      });
    }
  }
  console.log("user Places outside are >>>>>>>>>>>>>>>>>>> : ", userPlaces);

  // THIS IS REMOVING ALL THE PLACES INSTEAD OF REMOVING SELECTED PLACE ONLY
  const handleRemovePlace = useCallback(
    async function handleRemovePlace() {
      let newPlaces;
      setUserPlaces((prevPickedPlaces) => {
        console.log(
          "prevPickedPlaces are >>>>>>>>>>>>>>>>>>> : ",
          prevPickedPlaces
        );
        newPlaces = prevPickedPlaces.filter(
          (place) => place.id !== selectedPlace.current.id
        );
        return newPlaces;
      });

      try {
        console.log("user Places are >>>>>>>>>>>>>>>>>>> : ", newPlaces);
        await updateSelectedPlaces(newPlaces);
      } catch (error) {
        setUserPlaces(userPlaces);
        console.error("Error updating selected places:", error);
        setErrorSelectPlaces({ message: "Failed to update the place!" });
      }

      setModalIsOpen(false);
    },
    [userPlaces, setUserPlaces]
  );

  // const handleRemovePlace = useCallback(async function handleRemovePlace() {
  //   setUserPlaces(async (prevPickedPlaces) => {
  //     const newPlaces = prevPickedPlaces.filter((place) => place.id !== selectedPlace.current.id);
  //     try {
  //       console.log("user Places are >>>>>>>>>>>>>>>>>>> : ", userPlaces);
  //       await updateSelectedPlaces(newPlaces);
  //       return newPlaces;
  //     } catch (error) {
  //       console.error('Error updating selected places:', error);
  //       setErrorSelectPlaces({message: 'Failed to update the place!'});
  //       return userPlaces;
  //     }
  //   });

  //   setModalIsOpen(false);
  // }, []);

  function handleErrorClose() {
    setErrorSelectPlaces(null);
  }

  return (
    <>
      <Modal open={errorSelectPlaces} onClose={handleErrorClose}>
        {errorSelectPlaces && (
          <Error
            title="Error selecting places"
            message={errorSelectPlaces.message}
            onConfirm={handleErrorClose}
          />
        )}
      </Modal>
      <Modal open={modalIsOpen} onClose={handleStopRemovePlace}>
        <DeleteConfirmation
          onCancel={handleStopRemovePlace}
          onConfirm={handleRemovePlace}
        />
      </Modal>

      <header>
        <img src={logoImg} alt="Stylized globe" />
        <h1>PlacePicker</h1>
        <p>
          Create your personal collection of places you would like to visit or
          you have visited.
        </p>
      </header>
      <main>
        {errorFetchSelectPlaces && (
          <Error
            title="Error fetching user places"
            message={errorFetchSelectPlaces.message}
          />
        )}
        {!errorFetchSelectPlaces && (
          <Places
            title="I'd like to visit ..."
            fallbackText="Select the places you would like to visit below."
            places={userPlaces}
            onSelectPlace={handleStartRemovePlace}
            isFetching={isFetching}
            fetchingFallbackText="Loading your selected places..."
          />
        )}

        <AvailablePlaces onSelectPlace={handleSelectPlace} />
      </main>
    </>
  );
}

export default App;
