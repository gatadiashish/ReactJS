import { useEffect, useState } from "react";

export function useFetch(func) {
  const [fetchedData, setFetchedData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState();

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const places = await func();
        setFetchedData(places);
      } catch (error) {
        // console.error('Error fetching places:', error);
        setError(error);
      }
      setIsLoading(false);
    }
    fetchData();
  }, [func]);
  return {
    fetchedData,
    setFetchedData,
    isLoading,
    error,
  };
}
