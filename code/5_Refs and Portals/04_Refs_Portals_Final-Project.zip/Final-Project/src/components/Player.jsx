import { useState, useRef } from "react";

export default function Player() {
  const [name, setName] = useState("unknown entity");
  const inputRef = useRef();

  function onSetNameClick() {
    setName(inputRef.current.value);
    inputRef.current.value = "";
  }
  return (
    <section id="player">
      <h2>Welcome {name}</h2>
      <p>
        <input type="text" ref={inputRef}/>
        <button onClick={onSetNameClick}>Set Name</button>
      </p>
    </section>
  );
}
