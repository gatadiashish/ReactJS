import { useImperativeHandle, useRef } from "react";
import { createPortal } from "react-dom";


export function ResultModal ({ onReset, timeLeftOut, targetTime, ref }) {
    const timeLeft = Math.abs(timeLeftOut / 1000).toFixed(2);
    const score = Math.round((1 - timeLeftOut/(targetTime*1000))*100);
    const result = timeLeftOut > 0 ? `Your score is ${score}` : 'You lost';
    const dialog = useRef();
    useImperativeHandle(ref, () => {
        return {
            open() {
                dialog.current.showModal();
            }
        }
    });

    return ( createPortal(
        <dialog ref={dialog} className="result-modal" onClose={onReset}>
            <h2>{result}</h2>
            <p>Target Time was <strong>{targetTime}</strong> seconds</p>
            <p>You stopped the timer with <strong>{timeLeft} seconds left.</strong></p>
            <form method="dialog" onSubmit={onReset}>
                <button>Close</button>
            </form>
        </dialog>, 
        document.getElementById('modal'))
    );
}