import {
  require_react
} from "./chunk-65RTBKR7.js";
export default require_react();
//# sourceMappingURL=react.js.map
