import React from "react";
import ReactDOM from "react-dom/client";

import "./index.css";
import App from "./App";
import { Provider } from "../node_modules/react-redux/dist/react-redux";
// import store from "./store/index";
import storeToolKit from "./store/Store";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  //   <Provider store={store}>
  <Provider store={storeToolKit}>
    <App />
  </Provider>
);
