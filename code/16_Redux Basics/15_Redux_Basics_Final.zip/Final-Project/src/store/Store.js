/* This is the Store of the application created using Redux ToolKit(Reduxjs/toolkit) */

import { configureStore } from "@reduxjs/toolkit";

import counterReducer from "../store/counter-slice";
import authReducer from "../store/auth-slice";

const storeToolKit = configureStore({
  reducer: {
    counter: counterReducer,
    auth: authReducer,
  },
});

export default storeToolKit;
