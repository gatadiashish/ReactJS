/* This is store created using Redux library */
import { createStore } from "../../node_modules/redux/dist/redux";

const initialState = { counter: 0, showCounter: true };
const reducer = (state = initialState, action) => {
  if (action.type === "increment") {
    const incVal = action.amount ? action.amount : 1;
    return { counter: state.counter + incVal, showCounter: state.showCounter };
  }
  if (action.type === "decrement") {
    return { counter: state.counter - 1, showCounter: state.showCounter };
  }
  if (action.type === "toggle") {
    return {
      counter: state.counter,
      showCounter: !state.showCounter,
    };
  }

  return state;
};

const store = createStore(reducer);

export default store;
