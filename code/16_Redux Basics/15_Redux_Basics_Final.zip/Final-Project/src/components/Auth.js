import { useDispatch } from "../../node_modules/react-redux/dist/react-redux";
import { authActions } from "../store/auth-slice";
import classes from "./Auth.module.css";

const Auth = () => {
  const dispatch = useDispatch();

  const handleAuth = (event) => {
    event.preventDefault();
    // Add your authentication logic here
    const fd = new FormData(event.target);
    const data = Object.fromEntries(fd.entries());
    console.log("data: ", data);
    const email = fd.get("email");
    const password = fd.get("password");
    if (email === "test@abc.com" && password === "test") {
      dispatch(authActions.login());
    }
  };
  return (
    <main className={classes.auth}>
      <section>
        <form onSubmit={handleAuth}>
          <div className={classes.control}>
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" />
          </div>
          <div className={classes.control}>
            <label htmlFor="password">Password</label>
            <input type="password" id="password" name="password" />
          </div>
          <button>Login</button>
        </form>
      </section>
    </main>
  );
};

export default Auth;
