/* This is a component that used redux to maintain store and The store is created using Redux library */
import {
  useDispatch,
  useSelector,
} from "../../node_modules/react-redux/dist/react-redux";
import classes from "./Counter.module.css";

const CounterRedux = () => {
  const dispatch = useDispatch();
  const counter = useSelector((state) => state.counter);
  const showToggle = useSelector((state) => state.showCounter);

  const incrementHandler = () => {
    dispatch({ type: "increment" });
  };

  const decrementHandler = () => {
    dispatch({ type: "decrement" });
  };

  const incrementHandlerBy = () => {
    dispatch({ type: "increment", amount: 5 });
  };

  const toggleCounterHandler = () => {
    dispatch({ type: "toggle" });
  };

  return (
    <main className={classes.counter}>
      <h1>Redux Counter</h1>
      {showToggle && <div className={classes.value}>{counter}</div>}
      <div className={classes.buttonDiv}>
        <button className={classes.buttonDiv} onClick={incrementHandler}>
          increment
        </button>
        <button className={classes.buttonDiv} onClick={incrementHandlerBy}>
          Increase by 5
        </button>
        <button className={classes.buttonDiv} onClick={decrementHandler}>
          decrement
        </button>
      </div>
      <button onClick={toggleCounterHandler}>Toggle Counter</button>
    </main>
  );
};

export default CounterRedux;
