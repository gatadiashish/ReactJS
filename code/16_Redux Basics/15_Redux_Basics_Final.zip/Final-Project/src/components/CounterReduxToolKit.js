/* This is a component that used redux to maintain store and The store is created using Redux toolkit library */
import { useDispatch, useSelector } from "react-redux";
import { counterActions } from "../store/counter-slice";
import classes from "./Counter.module.css";

const CounterReduxToolKit = () => {
  const dispatch = useDispatch();
  const counter = useSelector((state) => state.counter.counter);
  const showToggle = useSelector((state) => state.counter.showCounter);

  const incrementHandler = () => {
    console.log("increment");
    dispatch(counterActions.increment());
  };

  const decrementHandler = () => {
    dispatch(counterActions.decrement());
  };

  const incrementHandlerBy = () => {
    dispatch(counterActions.increment({ amount: 5 }));
  };

  const toggleCounterHandler = () => {
    dispatch(counterActions.toggleCounter());
  };

  return (
    <main className={classes.counter}>
      <h1>Redux Counter</h1>
      {showToggle && <div className={classes.value}>{counter}</div>}

      <div className={classes.buttonDiv}>
        <button className={classes.buttonDiv} onClick={incrementHandler}>
          increment
        </button>
        <button className={classes.buttonDiv} onClick={incrementHandlerBy}>
          Increase by 5
        </button>
        <button className={classes.buttonDiv} onClick={decrementHandler}>
          decrement
        </button>
      </div>
      <button onClick={toggleCounterHandler}>Toggle Counter</button>
    </main>
  );
};

export default CounterReduxToolKit;
