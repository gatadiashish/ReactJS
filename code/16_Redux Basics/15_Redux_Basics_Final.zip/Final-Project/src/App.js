import { useSelector } from "../node_modules/react-redux/dist/react-redux";
import Auth from "./components/Auth";
import CounterReduxToolKit from "./components/CounterReduxToolKit";
import Header from "./components/Header";
import UserProfile from "./components/UserProfile";
// import Counter from "./components/CounterReduxToolKit";

function App() {
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);

  return (
    <>
      <Header />
      {!isLoggedIn && <Auth />}
      {isLoggedIn && <UserProfile />}
      {isLoggedIn && <CounterReduxToolKit />}
    </>
  );
}

export default App;
