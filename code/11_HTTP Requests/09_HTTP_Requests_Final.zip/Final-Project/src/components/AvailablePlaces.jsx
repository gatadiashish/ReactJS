import { useEffect, useState } from 'react';
import Places from './Places.jsx';
import Error from './Error.jsx';
import { fetchPlaces } from '../http.js';

export default function AvailablePlaces({ onSelectPlace }) {
  const [availablePlaces, setAvailablePlaces] = useState([]);
  const [isFetching, setIsFetching] = useState(false);
  const [error, setError] = useState();

  // useEffect(() => {
  //   fetch('http://localhost:3000/places')
  //   .then((response) => response.json())
  //   .then((data) => setAvailablePlaces(data.places))
  //   .catch((error) => console.error('Error fetching places:', error));
  // }, [])

  // USING ASYNC AWAIT BY CREATING A FUNCTION INSIDE useEffect
  useEffect(() => {
    async function fetchAvailablePlaces() {
      setIsFetching(true)
      try {
        const places = await fetchPlaces('http://localhost:3000/places');
        setAvailablePlaces(places);
        
      } catch (error) {
        // console.error('Error fetching places:', error);
        setError(error);
      }
      setIsFetching(false)
    }
    fetchAvailablePlaces();
  }, []);

  // USING ASYNC AWAIT BY CREATING A ANONYMOUS FUNCTION INSIDE useEffect - NOT WORKING
  // useEffect(() => {
  //   async () => {
  //     const response = await fetch('http://localhost:3000/places');
  //     const data = await response.json();
  //     setAvailablePlaces(data.places);
  //   }
  // }, []);

  if(error) {
    return <Error title="Error fetching places" message={error.message || 'Something went wrong! Please try again after sometime'} />
  }
  
  return (
    <Places
      title="Available Places"
      places={availablePlaces}
      isFetching={isFetching}
      fetchingFallbackText="Loading Available places..."
      fallbackText="No places available."
      onSelectPlace={onSelectPlace}
    />
  );
}
