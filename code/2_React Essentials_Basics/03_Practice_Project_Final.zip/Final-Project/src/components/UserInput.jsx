

export function UserInput({inputData, onInputChange}) {


    return (
        <>
            <section id='user-input'>
                <div className='input-group'>
                    <p>
                        <label htmlFor='amount'>Initial Investment Amount:</label>
                        <input type='number' id='amount' required value={inputData.initialInvestment} onChange={(e) => onInputChange(e, 'initialInvestment')} />
                    </p>
                    <p>
                        <label htmlFor='duration'>Annual Investment Amount:</label>
                        <input type='number' id='duration' required value={inputData.annualInvestment} onChange={(e) => onInputChange(e, 'annualInvestment')} />
                    </p>
                </div>
                <div className='input-group'>
                    <p>
                        <label htmlFor='amount'>Expected Returns:</label>
                        <input type='number' id='amount' required  value={inputData.expectedReturn} onChange={(e) => onInputChange(e, 'expectedReturn')}/>
                    </p>
                    <p>
                        <label htmlFor='duration'>Investment Duration (years):</label>
                        <input type='number' id='duration' required value={inputData.duration} onChange={(e) => onInputChange(e, 'duration')} />
                    </p>
                </div>
                <button>Calculate</button>
            </section>
            
        </>
    );
}
