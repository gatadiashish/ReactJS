import calculatorImage from '/investment-calculator-logo.png'

export function Header() {
    return (
        <header id='header'>
            <img src={calculatorImage} alt="Investment Calculator" />
            <h1>Investment Calculator</h1>
        </header>
    );
}