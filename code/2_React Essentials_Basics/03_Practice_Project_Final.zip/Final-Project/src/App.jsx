import { useState } from "react";
import { Header } from "./components/Header"
import { UserInput } from "./components/UserInput.jsx"
import { Results } from "./components/Results.jsx";

function App() {
  const [userInput, setUserInput] = useState({
        initialInvestment: 10000,
        annualInvestment: 1000,
        expectedReturn: 10,
        duration: 10
    });

    function handleInputChange(event, inputField) {
        setUserInput((prevState) => {
            return {
                ...prevState,
                [inputField]: +event.target.value
            };
        })
    }
  return (
    <>
      <Header />
      <UserInput inputData={userInput} onInputChange={handleInputChange} />
      <Results investmentData={userInput} />
    </>
  )
}

export default App
