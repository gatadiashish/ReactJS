
import { CoreConceptsSection } from './components/CoreConceptsSection.jsx';
import { Examples } from './components/Examples.jsx';
import AppHeader from './components/Header/AppHeader.jsx';

function App() {
  
  return (
    <div>
      <AppHeader />
      <main>
        <CoreConceptsSection />
        <Examples />
      </main>
    </div>
  );

}



export default App;
