

/*
 Using object DESTRUCTURING
*/
export default function CoreConcepts({ image, title, description }) {
  return (
    
      <li>
        <img src={image}></img>
        <h3>{title}</h3>
        <p>{description}</p>
      </li>
  );
}


// function CoreConcepts(props) {
//   return (
    
//       <li>
//         <img src={props.image}></img>
//         <h3>{props.title}</h3>
//         <p>{props.description}</p>
//       </li>
//   );
// }