import { useState } from 'react';
import { CORE_CONCEPTS, EXAMPLES } from '../data';
import { TabButton } from './TabButton';
import { Section } from './Section';
import { Tabs } from './Tabs';
export function Examples() {
    const [tabContent, setTabContent] = useState();
      let selectedContent = 'Please select a topic';
      if (tabContent) {
        selectedContent = (<div id="tab-content">
          <h3>{EXAMPLES[tabContent]?.title}</h3>
          <p>{EXAMPLES[tabContent]?.description}</p>
          <pre>
            <code>
              {EXAMPLES[tabContent]?.code}
            </code>
          </pre>
        </div>);
      }

    function clickHandler(tabClicked) {
    // console.log(`Tab clicked: ${props.children}`);
    setTabContent(tabClicked);
    console.log("Tab Clicked - ", tabContent);
  }

    return (
        <Section title='Examples' id='examples'>
            <Tabs 
                buttons={  <>  
                <TabButton isActive={tabContent === 'components'} onClick={() => clickHandler('components')}>{CORE_CONCEPTS[0].title}</TabButton>
                <TabButton isActive={tabContent === 'jsx'} onClick={() => clickHandler('jsx')}>{CORE_CONCEPTS[1].title}</TabButton>
                <TabButton isActive={tabContent === 'props'} onClick={() => clickHandler('props')}>{CORE_CONCEPTS[2].title}</TabButton>
                <TabButton isActive={tabContent === 'state'} onClick={() => clickHandler('state')}>{CORE_CONCEPTS[3].title}</TabButton>
            </>
            }>
            
            {selectedContent}
            </Tabs>
        </Section>
    );
}