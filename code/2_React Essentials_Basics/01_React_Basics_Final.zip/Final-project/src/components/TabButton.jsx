export function TabButton({isActive, children, ...props}) {

    return (
        <button className={isActive ? 'active' : ''} {...props}>{children}</button>
    );
}