import { useState } from "react"
import { GameBoard } from "./Components/GameBoard"
import Player from "./Components/Player"
import { Logs } from "./Components/logs";
import { WINNING_COMBINATIONS } from "./winning-combinations";
import { GameOver } from "./Components/GameOver";

const initialGameBoard = [
  [null, null, null],
  [null, null, null],
  [null, null, null]
];

function retrieveActivePlayer(gameTurns) {
  let player = 'X';
  if (gameTurns.length > 0) {
    player = gameTurns[0].player === 'X' ? 'O' : 'X';
  }
  return player;
}

function App() {

  // const [activePlayer, setActivePlayer] = useState('X');
  const [gameTurns, setGameTurns] = useState([]);
  const [players, setPlayers] = useState({
    X: "Player 1",
    O: "Player 2"
  });

  const activePlayer = retrieveActivePlayer(gameTurns);

  let gameBoard = initialGameBoard.map(row => row.slice()); // Create a copy of the initial game board
  for (const turn of gameTurns) {
    const { square, player } = turn;
    gameBoard[square.row][square.col] = player;
  }
  let winner;
  for(const combination of WINNING_COMBINATIONS) {
    const [first, second, third] = combination;
    if (gameBoard[first.row][first.column] && 
        gameBoard[first.row][first.column] === gameBoard[second.row][second.column] &&
        gameBoard[first.row][first.column] === gameBoard[third.row][third.column]) {
      // alert(`Player ${gameBoard[first.row][first.column]} wins!`);
      winner = gameBoard[first.row][first.column];
      //return;
    }
  }

  const isDraw = gameTurns.length === 9 && !winner;

  function handleSquareClick(rowIndex, colIndex) {
    console.log("handleSquareClick")
    setGameTurns((prevTurns) => {
      let currentPlayer = retrieveActivePlayer(prevTurns);
      const updatedTurn = [{ square: { row: rowIndex, col: colIndex }, player: currentPlayer }, ...prevTurns];
      return updatedTurn;
    });
  }

  function handleNameChange(symbol, newName) {
    setPlayers((prevPlayers) => ({
      ...prevPlayers,
      [symbol]: newName
    }));
  }

  function handleRestart() {
    setGameTurns([])
  }

  return (
    <main>
      <div id="game-container">
        <ol id="players" className="highlight-player">
          <Player playerName="player-1" symbol="X" isActive={activePlayer === 'X'} saveNameChange={handleNameChange} />
          <Player playerName="player-2" symbol="O" isActive={activePlayer === 'O'} saveNameChange={handleNameChange} />
        </ol>
        {(winner || isDraw) && <GameOver winner={players[winner]} restartGame={handleRestart} />}
        <GameBoard setActivePlayer={handleSquareClick} board={gameBoard} />
      </div>
      <Logs turns={gameTurns} />
    </main>
  )
}

export default App
