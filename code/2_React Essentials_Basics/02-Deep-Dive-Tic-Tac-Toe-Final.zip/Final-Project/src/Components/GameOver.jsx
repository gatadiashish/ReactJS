export function GameOver({winner, restartGame}) {
    return(
        <div id="game-over">
            <h2>Game Over!</h2>
            {winner && <p>Congratulations, {winner}!</p>}
            
            {!winner && <p>It's a draw!</p>}
            <p><button onClick={() => restartGame()}>Play Again</button></p>
        </div>
    );
}