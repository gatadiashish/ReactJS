import { useState } from "react";

export default function Player({ playerName, symbol, isActive, saveNameChange }) {
    const [isEditing, setIsEditing] = useState(false);
    const [name, setPlayerName] = useState(playerName);

    const handleEdit = () => {
        setIsEditing((editing) => !editing);
        if(isEditing) {
            saveNameChange(symbol, name);
        }
    };

    const handleChange = (event) => {
        setPlayerName(event.target.value);
    };

    // const handleSave = () => {
    //     setIsEditing(false);
    // };

    return (
        <li className={isActive ? "active" : ""}>
            <span className="player">
                {isEditing ? (
                    <input type="text" value={name} onChange={handleChange} required />) : 
                    (<span className="player-name">{name}</span>)}
                
                <span className="player-symbol">{symbol}</span>
            </span>

            <button onClick={handleEdit}>{isEditing ? "save" : "edit"}</button>

        </li>
    );
}