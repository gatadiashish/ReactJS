

export function GameBoard ({setActivePlayer, board}) {
    // const [gameBoard, setGameBoard] = useState(initialGameBoard);

    

    // function handleSelectSquare(rowIndex, colIndex) {
    //     setGameBoard((prevBoard) => {
    //         const newBoard = prevBoard.map((row) => row.slice());
    //         if (!newBoard[rowIndex][colIndex]) {
    //             newBoard[rowIndex][colIndex] = activePlayer;
    //         }
    //         //  const updatedBoard = [...prevBoard.map(row => [...row])];
    //         // updatedBoard[rowIndex][colIndex] = "X"; // For simplicity, always placing "X"
    //         // return updatedBoard;
    //         return newBoard;
    //     });
    //     setActivePlayer();
    // }

    return (
        <ol id="game-board">
            {board.map((row, rowIndex) => (
                <li key={rowIndex} >
                    <ol>
                        {row.map((playerSymbol, colIndex) => (
                            <li key={colIndex} >
                                <button disabled={!!playerSymbol} onClick={() => setActivePlayer(rowIndex, colIndex)}>{playerSymbol}</button>
                            </li>
                        ))}
                    </ol>
                </li>
            ))}
        </ol>
    );
}