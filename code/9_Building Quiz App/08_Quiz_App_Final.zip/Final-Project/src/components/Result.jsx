import trophyImage from "../assets/quiz-complete.png";
export function Result() {
    return (
            <div id="summary">
                <img src={trophyImage} alt="Trophy icon" />
                <h2> Quiz Completed!</h2>
            </div>
        )
}