import QUESTIONS from '../questions.js';

export function Answers({activeQuestionIndex, handleSelectAnswer, shuffledAnswers}) {
    return(
        <>
        <h2>{QUESTIONS[activeQuestionIndex].text}</h2>
            <ul id="answers">
                {shuffledAnswers.map((answer, index) => (
                    <li key={index} className="answer">
                        <button onClick={() => handleSelectAnswer(answer)}>{answer}</button>
                    </li>
                ))}
            </ul>
        </>
    );
}