import { useEffect, useState } from "react";

export function QuestionTimer({ timeout, onTimeout }) {

    const [timeRemaining, setTimeRemaining] = useState(timeout);

    useEffect(() => {
        // console.log("SET TIMER");
        const timer = setTimeout(onTimeout, timeout);
        return () => clearTimeout(timer);
    }, [onTimeout, timeout]);

    useEffect(() => {
        // console.log("SET INTERVAL");
        const interval = setInterval((prev) => {
            setTimeRemaining((prev) => prev - 100);
        }, 100);
        return () => clearInterval(interval);
    }, []);


    return (
        <progress id="question-timer" value={timeRemaining} max={timeout} />
    );
}