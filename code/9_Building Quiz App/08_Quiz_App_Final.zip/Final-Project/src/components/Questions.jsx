import { useCallback, useState } from 'react';
import QUESTIONS from '../questions.js';
import { Answers } from './Answers.jsx';
import { QuestionTimer } from './QuestionTimer.jsx';
import { Result } from './Result.jsx';

export function Questions() {
    const [answers, setAnswers] = useState({
        answer: '',
        isCorrect: null
    });
    const [answerResult, setAnswerResult] = useState('');

    const activeQuestionIndex = answerResult === '' ? answers.length : answers.length - 1;
    const isQuizComplete = activeQuestionIndex === QUESTIONS.length;

    const handleSelectAnswer = useCallback(function handleSelectAnswer(answer) {
        setAnswers((prevAnswers) => {
            return [...prevAnswers, answer = answer];
        });

        setTimeout(() => {
            setAnswers((prevAnswers) => { return [...prevAnswers, answer] });
            setAnswerResult('selected');
            if (answer === QUESTIONS[activeQuestionIndex].answers[0]) {
                console.log("Correct answer selected!");
                setAnswerResult('correct');
            } else {
                console.log("Incorrect answer selected!");
                setAnswerResult('wrong');
            }
            setTimeout(() => {
                setAnswerResult('');
            }, 1000);
            // setAnswers([...answers, answer]);

        }, 2000);
    }, [activeQuestionIndex]);

    const handleSkipAnswer = useCallback(() => handleSelectAnswer(null), [handleSelectAnswer]);

    if (isQuizComplete) {
        <Result/>
    }
    const shuffledAnswers = [...QUESTIONS[activeQuestionIndex].answers]
    shuffledAnswers.sort(() => Math.random() - 0.5);
    return (
        <>
            <QuestionTimer key={activeQuestionIndex} timeout={10000} onTimeout={handleSkipAnswer} />
            <Answers activeQuestionIndex={activeQuestionIndex} handleSelectAnswer={handleSelectAnswer} shuffledAnswers={shuffledAnswers} />
        </>
    );
}