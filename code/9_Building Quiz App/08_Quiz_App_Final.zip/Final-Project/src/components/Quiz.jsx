import { useCallback, useState } from "react";
import QUESTIONS from "../questions.js";
import { Questions } from "./Questions.jsx";
import { Result } from "./Result.jsx";

export default function Quiz() {
    
    // const handleSelectAnswer = useCallback(function handleSelectAnswer(answer) {

    //     setTimeout(() => {
    //         setAnswers((prevAnswers) => { return [...prevAnswers, answer] });
    //         setAnswerResult('selected');
    //         if (answer === QUESTIONS[activeQuestionIndex].answers[0]) {
    //             console.log("Correct answer selected!");
    //             setAnswerResult('correct');
    //         } else {
    //             console.log("Incorrect answer selected!");
    //             setAnswerResult('wrong');
    //         }
    //         setTimeout(() => {
    //             setAnswerResult('');
    //         }, 2000);
    //         // setAnswers([...answers, answer]);

    //     }, 2000);
    // }, [activeQuestionIndex]);

    return (
        <>
            <div id="quiz">
                <div id="question">
                    <Questions  />
                </div>
            </div>
        </>
    );
}