import { useState } from "react";

export default function useInput(defaultValue, validationFunction) {
  const [formData, setFormData] = useState(defaultValue);
  const [isEdited, setIsEdited] = useState(false);

  const isError = isEdited && !validationFunction(formData);
  function handleFormDataChange(event) {
    setFormData(event.target.value);
    setIsEdited(false);
  }

  function handleInputBlur() {
    setIsEdited(true);
  }

  return {
    formData,
    isEdited,
    handleFormDataChange,
    handleInputBlur,
    isError,
  };
}
