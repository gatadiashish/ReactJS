import { hasMinLength, isEmail } from "../util/validation";
import Input from "./Input";
import useInput from "../hooks/useInput";

export default function Login() {
  const {
    formData: emailValue,
    isEdited: emailEdited,
    handleFormDataChange: handleEmailChange,
    handleInputBlur: handleEmailBlur,
    isError: isEmailError,
  } = useInput("", (value) => isEmail(value));

  const {
    formData: passwordValue,
    isEdited: passwordEdited,
    handleFormDataChange: handlePasswordChange,
    handleInputBlur: handlePasswordBlur,
    isError: isPasswordError,
  } = useInput("", (value) => hasMinLength(value, 6));

  function onSubmit(event) {
    event.preventDefault();
    console.log("Form Submitted..!!");
    console.log(emailValue, passwordValue);
  }

  return (
    <form onSubmit={onSubmit}>
      <h2>Login</h2>

      <div className="control-row">
        <Input
          label="Email"
          id="email"
          type="email"
          name="email"
          value={emailValue}
          onBlur={handleEmailBlur}
          onChange={handleEmailChange}
          error={isEmailError && "Please enter a valid email address."}
        />

        <Input
          label="Password"
          id="password"
          type="password"
          name="password"
          value={passwordValue}
          onBlur={handlePasswordBlur}
          onChange={handlePasswordChange}
          error={isPasswordError && "Please enter a valid password."}
        />
      </div>

      <p className="form-actions">
        <button className="button button-flat">Reset</button>
        <button className="button">Login</button>
      </p>
    </form>
  );
}
