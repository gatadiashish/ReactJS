import { useState } from "react";
import { hasMinLength, isEmail } from "../util/validation";
import Input from "./Input";

export default function Login() {
  // const [email, setEmail] = useState("");
  // const [password, setPassword] = useState("");
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [isEdited, setIsEdited] = useState({
    email: false,
    password: false,
  });

  // const isEmailValid = isEdited.email && !formData.email.includes("@");
  // const isPasswordValid =
  //   isEdited.password && formData.password.trim().length < 6;

  // Outsourcing validation logic
  const isEmailValid = isEdited.email && !isEmail(formData.email);
  const isPasswordValid =
    isEdited.password && !hasMinLength(formData.password, 6);

  function onSubmit(event) {
    event.preventDefault();
    console.log("Form Submitted..!!");
    console.log(formData);
  }

  // function handleEmailChange(event) {
  //   setEmail(event.target.value);
  // }

  // function handlePasswordChange(event) {
  //   setPassword(event.target.value);
  // }

  function handleFormDataChange(id, value) {
    setFormData((prevData) => ({
      ...prevData,
      [id]: value,
    }));
    setIsEdited((prevState) => ({
      ...prevState,
      [id]: false,
    }));
  }

  function handleInputBlur(id) {
    setIsEdited((prevState) => ({
      ...prevState,
      [id]: true,
    }));
  }

  return (
    <form onSubmit={onSubmit}>
      <h2>Login</h2>

      <div className="control-row">
        <Input
          label="Email"
          id="email"
          type="email"
          name="email"
          value={formData.email}
          onBlur={() => handleInputBlur("email")}
          onChange={(event) =>
            handleFormDataChange("email", event.target.value)
          }
          error={isEmailValid && "Please enter a valid email address."}
        />

        <Input
          label="Password"
          id="password"
          type="password"
          name="password"
          value={formData.password}
          onBlur={() => handleInputBlur("password")}
          onChange={(event) =>
            handleFormDataChange("password", event.target.value)
          }
          error={isPasswordValid && "Please enter a valid password."}
        />
      </div>

      <p className="form-actions">
        <button className="button button-flat">Reset</button>
        <button className="button">Login</button>
      </p>
    </form>
  );
}
