/* eslint-disable react/react-in-jsx-scope */
import Header from "./components/Header.jsx";
import Login from "./components/State_Login.jsx";
// import Signup from "./components/Signup.jsx";

function App() {
  return (
    <>
      <Header />
      <main>
        <Login />
        {/* <Signup /> */}
      </main>
    </>
  );
}

export default App;
