import { useRef } from "react";
import { CustomDialog } from "./CustomDialog";

export function AddProject( { isAddProjectClicked, saveProject } ) {
    const projectName = useRef();
    const projectDesc = useRef();
    const dialog = useRef();
    const dueDate = useRef();
    const errorType = "Validation Error";
    const errorMessage = "All fields are required.";
    const classesForFields = "w-full p-1 border-b-2 rounded-sm border-stone-300 bg-stone-200 text-stone-600 focus:outline-none focus:border-stone-600";
    const classesForButton="px-4 py-2 text-xs md:text-base rounded-md bg-stone-700 text-stone-400 hover:bg-stone-600 hover:text-stone-100";
    
    function createProject() {
        const projectNameValue = projectName.current.value.trim();
        const projectDescValue = projectDesc.current.value.trim();
        const dueDateValue = dueDate.current.value.trim();
        if(projectNameValue === "" || projectDescValue === "" || dueDateValue === "") {
            
            dialog.current.open();
            return;
        }
        saveProject({
            isSelected: false,
            name: projectNameValue,
            description: projectDescValue,
            dueDate: dueDateValue,
            tasks:[]
        });
        isAddProjectClicked();
    }
    
    return (
        <>
        <CustomDialog type={errorType} message={errorMessage} ref={dialog} />
        <div className="w-[35rem] mt-16">
            <h2 className="mb-8 font-bold uppercase md:text-xl text-stone-800">Add New Project</h2>
            <div className="flex flex-col gap-4">
                <input ref={projectName} type="text" placeholder="Project Name" className={classesForFields} />
                <textarea ref={projectDesc} placeholder="Project Description" className={classesForFields}></textarea>
                <input ref={dueDate} type="date" placeholder="Due Date" className={classesForFields} />
                <menu className="flex justify-between items-center gap-4 mt-4">
                    <button type="submit" onClick={createProject} className={classesForButton}>Create Project</button>
                    <button type="submit" onClick={isAddProjectClicked}  className={classesForButton}>Cancel</button>
                </menu>
            </div>
        </div>
        </>
    );
}