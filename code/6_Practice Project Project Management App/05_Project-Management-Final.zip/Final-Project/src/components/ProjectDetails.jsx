import { Tasks } from "./Tasks";

export function ProjectDetails({ projectDataObj, onDeleteClick, onAddTasks, onDeleteTasks }) {
    console.log("projectDataObj >>>>>>>>>>>>>>>>> ", projectDataObj);
    return (
        <div>
            <header className="pb-4 mb-4 border-b-2 border-stone-300">
                {/* <h1 className="text-3xl font-bold text-stone-600 mb-2">Project Details</h1>
                <p className="mb-4 text-stone-600">Here you can view and edit project details.</p> */}
                <div className="mt-8">
                    <div className="flex items-center justify-between">
                        <h2 className="text-2xl font-semibold text-stone-600">{projectDataObj.name}</h2>
                        <button onClick={() => onDeleteClick(projectDataObj.id)} className="px-4 py-2 text-xs md:text-base rounded-md bg-stone-700 text-stone-400 hover:bg-stone-600 hover:text-stone-100">Delete Project</button>
                    </div>
                    
                    <p className="text-stone-600">Due Date: {projectDataObj.dueDate}</p>
                    <p className="text-stone-600 whitespace-pre-wrap">Description: {projectDataObj.description}</p>
                </div>
                
            </header>
            <Tasks tasksObject={projectDataObj.tasks} onAddTasks={onAddTasks} onDeleteTasks={onDeleteTasks} />
        </div>
    );
}