import { useImperativeHandle, useRef } from "react";
import { createPortal } from "react-dom";

export function CustomDialog({ ref, type, message }) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>",type, message);
    const dialog = useRef();
    useImperativeHandle(ref, () => ({
        open: () => {
            dialog.current.showModal();
        }
    }));
    return (createPortal(
        <dialog ref={dialog}>
            <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
                <div className="bg-white p-6 rounded-lg shadow-lg w-96">
                    <h2 className="text-xl font-bold mb-4">{type}</h2>
                    <p className="mb-4">{message}</p>
                    <form method="dialog" >
                        <button type="submit" className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Close</button>
                    </form>
                </div>
            </div>
        </dialog>, document.getElementById('modal-root'))
    );
}