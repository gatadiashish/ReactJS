import { CreateNewTask } from "./CreateNewTask";

export function Tasks({onDeleteTasks, onAddTasks, tasksObject}) {
    return(
        <section>
            <h2 className="text-2xl font-bold text-stone-700 mb-4">TASKS</h2>
            <CreateNewTask onAdd={onAddTasks} />
            <ul>
                <div>
                    {tasksObject.length === 0 ? (
                        <p className="text-stone-800 my-4">There are no tasks at present.</p>
                    ) : (
                        tasksObject.map((task) => (
                            <li key={task.id} className="border-b border-stone-300 py-2">
                                <div className="flex items-center justify-between">
                                    <span className="text-stone-600">{task.taskName}</span>
                                    <button onClick={() => onDeleteTasks(task.id)} className="text-red-500 hover:text-red-700">Delete</button>
                                </div>
                            </li>
                        ))
                    )}
                </div>
            </ul>
        </section>
    );
}