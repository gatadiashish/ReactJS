import noProjectImage from "../assets/no-projects.png";

export function NoProject( { isAddProjectLinkClicked } ) {
    return(
        <div className="mt-24 text-center w-2/3">
            <img src={noProjectImage} className="w-16 h-16 object-contain mx-auto"/>
        <h2 className="text-2xl text-stone-500 font-bold my-4">No Project Selected</h2>
        <p className="text-stone-400">Please select a project from the sidebar to view its details.</p>
        <p className="text-stone-400">Or click the <span className="text-stone-600 underline cursor-pointer"> <a onClick={isAddProjectLinkClicked}>Add Project</a></span> button to create a new project.</p>
        </div>
    );
}