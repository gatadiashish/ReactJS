import { useState } from "react";

export function CreateNewTask({ onAdd }) {
    const [addTask, setAddTask] = useState('');

    function handleAddTask() {
        onAdd({ taskName: addTask })
        setAddTask("");
    }

    function handleChange(event) {
        setAddTask(event.target.value);
        //onAdd(addTask);
    }
    return (
        <div className="flex items-center justify-between p-4 bg-stone-100 rounded shadow-md">
            <input type="text" value={addTask} onChange={handleChange} placeholder="Task Name" className="w-full p-2 mr-8 border-b-2 border-stone-300 bg-stone-200 text-stone-600 focus:outline-none focus:border-stone-600 mb-4" />
            <button onClick={handleAddTask} className="px-4 py-2 mb-4 bg-stone-700 text-white rounded hover:bg-stone-600">Add</button>
        </div>
    );
}