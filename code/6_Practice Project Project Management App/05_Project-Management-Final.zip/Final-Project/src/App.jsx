import { useState } from "react";
import { AddProject } from "./components/AddProject";
import { SideBar } from "./components/SideBar";
import { NoProject } from "./components/NoProject";
import { ProjectDetails } from "./components/ProjectDetails";

function App() {
  const [isAddButtonClicked, setIsAddButtonClicked] = useState(false);
  const [projectList, setProjectList] = useState([]);
  const [selectedProject, setSelectedProject] = useState(undefined);

  function addProject(projectData) {
    setProjectList((prev) => { 
      const newProject = { ...projectData, id: prev.length + 1 };
      return [...prev, newProject];
    });
  }

  function addTasks(taskDetails) {
    console.log("taskDetails >>>>>>>>>>>>> ", taskDetails);
    setProjectList((prev) => {
      return prev.map((proj) => {
        if (proj.id === selectedProject.id) {
          const newTask = { ...taskDetails, id: proj.tasks ? proj.tasks.length + 1 : 1 };
          console.log("newTask >>>>>>>>>>>>> ", newTask);
          const updatedProject = { ...proj, tasks: proj.tasks ? [newTask, ...proj.tasks] : [newTask] };
          setSelectedProject(updatedProject);
          return updatedProject;
        } else {
          return proj;
        }
      });
    });
    console.log("projectList after adding task >>>>>>>>>>>>> ", projectList);
  }

  function deleteTasks(id) {
    setProjectList((prev) => {
      return prev.map((proj) => {
        if (proj.id === selectedProject.id) {
          const updatedTasks = proj.tasks.filter((task) => task.id !== id);
          const updatedProject = { ...proj, tasks: updatedTasks };
          setSelectedProject(updatedProject);
          return updatedProject;
        } else {
          return proj;
        }
      });
    });
    console.log("projectList after deleting task >>>>>>>>>>>>> ", projectList);
  }
  
  function isAddProjectClicked() {
    setSelectedProject(undefined);
    setIsAddButtonClicked((prev) => {
      return !prev
    });
  }

  function onDeleteProject(projectId) {
    setProjectList((prev) => {
      return prev.filter((proj) => proj.id !== projectId);
    });
    setSelectedProject(undefined);
  }

  function onSelectProject(project) {
    console.log("projectList >>>>>>>>>>>>> ", projectList);
    console.log("project >>>>>>>>>>>>> ", project);
    setProjectList((prev) => {
      return prev.map((proj) => {
        if (proj.id === project.id) {
          const project = { ...proj, isSelected: true }
          setSelectedProject(project);
          return project;
        } else {
          return { ...proj, isSelected: false };
        }
      });
    });
    
  }console.log("selectedProject >>>>>>>>>>>>> ", selectedProject);

  return (
    <main className="h-screen my-8 flex gap-8">
      <SideBar selectProject={onSelectProject} listOfProjects={projectList} isAddProjectClicked={isAddProjectClicked} isButtonEnabled={isAddButtonClicked} />
      {(selectedProject === undefined || selectedProject.isSelected === false) && (isAddButtonClicked ? <AddProject saveProject={addProject} isAddProjectClicked={isAddProjectClicked} /> : <NoProject isAddProjectLinkClicked={isAddProjectClicked} />)}
      {(selectedProject && selectedProject.isSelected) && <ProjectDetails onAddTasks={addTasks} onDeleteTasks={deleteTasks} projectDataObj={selectedProject} onDeleteClick={onDeleteProject} />}
    </main>
  );
}

export default App;
