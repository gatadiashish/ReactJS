import {apiKey} from "./util.js";

console.log(apiKey);