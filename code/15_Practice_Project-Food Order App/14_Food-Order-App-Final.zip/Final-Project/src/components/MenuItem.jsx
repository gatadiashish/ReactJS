import { useContext } from "react";
import currencytoINRConverter from "../services/utility";
import { CartContext } from "../store/CartContext";

export default function MenuItem({ item }) {
  const { items, addItemToCart, removeItemFromCart } = useContext(CartContext);
  const quantity = items.find((i) => i.item.id === item.id)?.quantity || 0;
  return (
    <>
      <div className="meal-item">
        <article>
          <img src={`http://localhost:3000/${item.image}`} alt={item.name} />
          <div>
            <h3>{item.name}</h3>
            <div className="meal-item-price">
              {currencytoINRConverter(item.price)}
            </div>
            <div className="meal-item-description">{item.description}</div>
          </div>
          <p className="meal-item-actions">
            {quantity > 0 && (
              <>
                <button
                  className="button-cart"
                  onClick={() => removeItemFromCart(item.id)}
                >
                  <div style={{ fontSize: 15, fontWeight: "bold" }}>-</div>
                </button>
                <span
                  style={{
                    margin: "0 0.5rem",
                    fontWeight: "bold",
                    fontSize: 20,
                  }}
                >
                  {quantity}
                </span>
                <button
                  className="button-cart"
                  onClick={() => addItemToCart(item)}
                >
                  <div style={{ fontSize: 15, fontWeight: "bold" }}>+</div>
                </button>
              </>
            )}

            {quantity === 0 && (
              <button
                className="button button-font"
                onClick={() => addItemToCart(item)}
              >
                Add to cart (0)
              </button>
            )}
          </p>
        </article>
      </div>
    </>
  );
}
