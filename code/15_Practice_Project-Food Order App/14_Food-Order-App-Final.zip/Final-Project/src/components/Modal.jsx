import { useContext } from "react";
import { ModalContext } from "../store/ModalContext";

export default function Modal({ ref, children }) {
  const { closeModal, dialogRef } = useContext(ModalContext);
  //   const modalRef = useRef();
  //   useImperativeHandle(ref, () => ({
  //     open: () => {
  //       modalRef.current.showModal();
  //     },
  //     close: () => {
  //       modalRef.current.close();
  //     },
  //   }));

  //   function handleClose() {
  //     ref.current.close();
  //   }

  return (
    // <dialog ref={modalRef} className="modal" onClose={handleClose}>
    <dialog ref={dialogRef} className="modal" onClose={closeModal}>
      {children}
    </dialog>
  );
}
