export default function CustomError({ message, handleCloseModal }) {
  return (
    <>
      <div className="error">
        <h2>Error Occured</h2>
        <p>{message}</p>
      </div>
      <button type="button" className="text-button" onClick={handleCloseModal}>
        Close
      </button>
    </>
  );
}
