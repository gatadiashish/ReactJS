import { useEffect, useState } from "react";
import { fetchItems } from "../http";
import MenuItem from "./MenuItem";

export default function Menu() {
  const [menuItems, setMenuItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function fetchMenuItems() {
      setIsLoading(true);
      // Fetch menu items from an API or database
      const menuItems = await fetchItems("http://localhost:3000/meals");
      console.log(menuItems);
      setMenuItems(menuItems);
      setIsLoading(false);
    }

    fetchMenuItems();
  }, []);

  if (isLoading) {
    return <p style={{ textAlign: "center" }}>Loading...</p>;
  }

  return (
    <>
      <h1 style={{ textAlign: "center", color: "darkorchid" }}>Our Menu</h1>
      <div id="meals">
        {menuItems.map((item) => (
          <div key={item.id}>
            <MenuItem item={item} />
          </div>
        ))}
      </div>
    </>
  );
}
