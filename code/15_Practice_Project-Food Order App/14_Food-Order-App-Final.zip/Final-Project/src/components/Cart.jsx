import { useContext } from "react";
import currencytoINRConverter from "../services/utility";
import { CartContext } from "../store/CartContext";
import CartItem from "./CartItem";
import Checkout from "./Checkout";
import { ModalContext } from "../store/ModalContext";

export default function Cart({ dialogRef }) {
  const { items } = useContext(CartContext);
  //   const [isCheckoutClicked, setIsCheckoutClicked] = useState(false);
  const { closeModal, isCheckoutClicked, setIsCheckoutClicked } =
    useContext(ModalContext);
  const totalItemsPrice = items.reduce(
    (acc, curr) => acc + curr.item.price * curr.quantity,
    0
  );

  function handleCheckout() {
    console.log("inside handleCheckout");
    setIsCheckoutClicked(true);
  }

  function resetIsCheckoutClicked() {
    setIsCheckoutClicked(false);
  }

  return (
    <>
      {!isCheckoutClicked && (
        <>
          <div>
            <h2>Cart Items</h2>
            <ul>
              {items.map((item, index) => (
                <li className="cart-item" key={index}>
                  <CartItem item={item} />
                </li>
              ))}
            </ul>
          </div>
          <p className="cart-total">
            {currencytoINRConverter(totalItemsPrice)}
          </p>
          <div className="modal-actions">
            <button type="submit" className="text-button" onClick={closeModal}>
              Close
            </button>
            {items.length > 0 && (
              <button className="button button-font" onClick={handleCheckout}>
                Checkout
              </button>
            )}
          </div>
        </>
      )}
      {isCheckoutClicked && <Checkout reset={resetIsCheckoutClicked} />}
    </>
  );
}
