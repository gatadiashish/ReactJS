import { useContext } from "react";
import appLogo from "../assets/logo.jpg";
import { CartContext } from "../store/CartContext";
import Modal from "./Modal";
import Cart from "./Cart";
import { ModalContext } from "../store/ModalContext";
export default function Header() {
  const { items } = useContext(CartContext);
  const totalItems = items.reduce((acc, curr) => acc + curr.quantity, 0);
  const { openModal, dialogRef } = useContext(ModalContext);
  // const dialogRef = useRef();

  // function openModal() {
  //   dialogRef.current.open();
  // }
  return (
    <header id="main-header">
      <div id="title">
        <img src={appLogo} alt="Food Logo" />
        <h1>REACTFOOD</h1>
      </div>
      <button className="text-button" onClick={openModal}>
        cart({totalItems})
      </button>
      <Modal ref={dialogRef}>
        <Cart dialogRef={dialogRef} />
      </Modal>
    </header>
  );
}
