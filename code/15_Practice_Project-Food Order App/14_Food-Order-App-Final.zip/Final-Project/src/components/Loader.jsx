import { useRef } from "react";
import loading from "../assets/loading-icon.gif";

export default function Loader({ isOpen }) {
  const dialogRef = useRef();

  return (
    <dialog ref={dialogRef} className="modal dialog-modal" open={isOpen}>
      <img
        style={{ width: "100px", height: "100px" }}
        src={loading}
        alt="Loading..."
      />
    </dialog>
  );
}
