/* eslint-disable react-hooks/rules-of-hooks */
import { useContext } from "react";
import { ModalContext } from "../store/ModalContext";
import { CartContext } from "../store/CartContext";
import currencytoINRConverter from "../services/utility";
import { useActionState } from "react";
import useFetch from "../services/useFetch";
import CustomError from "./CustomError";
import Loader from "./Loader";

export default function Checkout({ reset }) {
  const { closeModal } = useContext(ModalContext);
  const { items, clearCart } = useContext(CartContext);

  const totalItemsPrice = items.reduce(
    (acc, curr) => acc + curr.item.price * curr.quantity,
    0
  );

  const { data, error, isLoading, fetchCall } = useFetch(
    "http://localhost:3000/orders"
  );

  function handleClose() {
    closeModal();
    reset();
    if (data.message === "Order created!") {
      clearCart();
    }
  }

  //   function handleSubmit() {
  //     setCartItems({
  //       items: [],
  //     });
  //   }

  async function handleFormSubmitAction(prevFormState, formData) {
    // Extract form data using Object.fromEntries

    // const dataObject = Object.fromEntries(formData.entries());
    // const submittedData = {
    //   order: {
    //     customer: dataObject,
    //   },
    //   errors: [],
    // };

    // Extract form data manually using get function

    const fullName = formData.get("fullName");
    const email = formData.get("email");
    const street = formData.get("street");
    const city = formData.get("city");
    const state = formData.get("state");
    const zip = formData.get("zip");
    const submittedData = {
      order: {
        customer: {
          name: fullName,
          email,
          street,
          city,
          state,
          "postal-code": zip,
        },
      },
      errors: [],
    };

    const errors = [];

    // if (!email.includes("@")) {
    //   errors.push("Invalid email address.");
    // }
    // if (!isNaN(zip) && isFinite(zip)) {
    //   errors.push("Invalid zip code.");
    // }

    if (errors.length > 0) {
      submittedData.errors = errors;
      return submittedData;
    } else {
      // try {
      //   const response = await fetch("http://localhost:3000/orders", {
      //     method: "POST",
      //     headers: {
      //       "Content-Type": "application/json",
      //     },
      //     body: JSON.stringify({
      //       order: {
      //         customer: submittedData.order.customer,
      //         items: items,
      //       },
      //     }),
      //   });
      //   submittedData.order.customer = await response.json();
      // } catch (error) {
      //   submittedData.errors = error;
      // }

      await fetchCall({
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          order: {
            customer: submittedData.order.customer,
            items: items,
          },
        }),
      });

      return { data: submittedData };
    }
  }

  const [checkoutFormState, checkoutFormStateAction, pending] = useActionState(
    handleFormSubmitAction,
    { error: null, data: null }
  );

  if (error) {
    return <CustomError message={error} handleCloseModal={handleClose} />;
  }

  if (isLoading) {
    return <p style={{ textAlign: "center" }}>Loading...</p>;
  }

  console.log("data - 1 >>>>>>>>>> ", data);
  console.log("error - 1 >>>>>>>>>> ", error);
  console.log("isLoading - 1 >>>>>>>>>> ", isLoading);
  if (data.message === "Order created!" && error === null) {
    // setCartItems({
    //   items: [],
    // });

    return (
      <>
        <p
          style={{
            fontWeight: "bold",
            fontSize: "1.5rem",
            textAlign: "center",
          }}
        >
          Order Created Successfully..!!
        </p>
        <button type="button" className="text-button" onClick={handleClose}>
          Close
        </button>
      </>
    );
  }

  return (
    <>
      <Loader isOpen={pending} />
      <div>
        <form action={checkoutFormStateAction}>
          <h2>Checkout</h2>
          <p className="checkout-total">
            Total Amount - {currencytoINRConverter(totalItemsPrice)}
          </p>
          <div className="control">
            <label htmlFor="fullName">Full Name</label>
            <input
              id="fullName"
              type="text"
              name="fullName"
              required
              defaultValue={checkoutFormState.data?.fullName || ""}
            />
          </div>
          <div className="control">
            <label htmlFor="email">Email-Address</label>
            <input
              id="email"
              type="email"
              name="email"
              required
              defaultValue={checkoutFormState.data?.email || ""}
            />
          </div>
          <div className="control-row">
            <div className="control">
              <label htmlFor="street">Street</label>
              <input
                id="street"
                type="text"
                name="street"
                required
                defaultValue={checkoutFormState.data?.street || ""}
              />
            </div>
            <div className="control">
              <label htmlFor="city">City</label>
              <input
                id="city"
                type="text"
                name="city"
                required
                defaultValue={checkoutFormState.data?.city || ""}
              />
            </div>
          </div>
          <div className="control-row">
            <div className="control">
              <label htmlFor="state">State</label>
              <input
                id="state"
                type="text"
                name="state"
                required
                defaultValue={checkoutFormState.data?.state || ""}
              />
            </div>
            <div className="control">
              <label htmlFor="zip">Zip Code</label>
              <input
                id="zip"
                type="number"
                name="zip"
                required
                defaultValue={checkoutFormState.data?.zip || ""}
              />
            </div>
          </div>
          {checkoutFormState.errors && (
            <ul className="error">
              {checkoutFormState.errors.map((error) => (
                <li key={error}>{error}</li>
              ))}
            </ul>
          )}
          <div className="control-row">
            <button type="button" className="text-button" onClick={handleClose}>
              Close
            </button>
            <button className="button">Submit Order</button>
          </div>
        </form>
      </div>
    </>
  );
}
