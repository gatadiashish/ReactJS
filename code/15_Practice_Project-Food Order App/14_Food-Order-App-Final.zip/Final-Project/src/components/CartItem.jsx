import { useContext } from "react";
import currencytoINRConverter from "../services/utility";
import { CartContext } from "../store/CartContext";

export default function CartItem({ item }) {
  const { addItemToCart, removeItemFromCart } = useContext(CartContext);
  return (
    <>
      {item.item.name} -
      <span
        style={{
          margin: "0 0.5rem",
          fontWeight: "bold",
          fontSize: 20,
        }}
      >
        = {currencytoINRConverter(item.item.price * item.quantity)}
      </span>
      <p className="cart-item-actions">
        <button
          type="button"
          className="button-cart"
          style={{ backgroundColor: "darkgreen", color: "white" }}
          onClick={() => removeItemFromCart(item.item.id)}
        >
          <div style={{ fontSize: 15, fontWeight: "bold" }}>-</div>
        </button>
        <span
          style={{
            margin: "0 0.5rem",
            fontWeight: "bold",
            fontSize: 20,
          }}
        >
          {item.quantity}
        </span>
        <button
          type="button"
          className="button-cart"
          style={{ backgroundColor: "darkgreen", color: "white" }}
          onClick={() => addItemToCart(item.item)}
        >
          <div style={{ fontSize: 15, fontWeight: "bold" }}>+</div>
        </button>
      </p>
    </>
  );
}
