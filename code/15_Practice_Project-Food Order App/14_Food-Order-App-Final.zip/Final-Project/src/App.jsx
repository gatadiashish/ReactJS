import Header from "./components/Header";
import Menu from "./components/Menu";
import { CartContextProvider } from "./store/CartContext";
import ModalContextProvider from "./store/ModalContext";

function App() {
  return (
    <>
      <CartContextProvider>
        <ModalContextProvider>
          <Header />
          <Menu />
        </ModalContextProvider>
      </CartContextProvider>
    </>
  );
}

export default App;
