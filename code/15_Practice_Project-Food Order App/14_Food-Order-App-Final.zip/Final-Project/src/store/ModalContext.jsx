import { createContext, useImperativeHandle, useRef, useState } from "react";

export const ModalContext = createContext({
  openModal: () => {},
  closeModal: () => {},
  dialogRef: null,
  isCheckoutClicked: false,
  setIsCheckoutClicked: () => {},
});

export default function ModalContextProvider({ children, ref }) {
  const modalRef = useRef();
  const [isCheckoutClicked, setIsCheckoutClicked] = useState(false);
  useImperativeHandle(ref, () => ({
    open: () => {
      modalRef.current.showModal();
    },
    close: () => {
      modalRef.current.close();
    },
  }));

  function closeModalWindow() {
    modalRef.current.close();
    setIsCheckoutClicked(false);
  }

  function openModalWindow() {
    modalRef.current.showModal();
  }
  const modalCtx = {
    openModal: openModalWindow,
    closeModal: closeModalWindow,
    dialogRef: modalRef,
    isCheckoutClicked,
    setIsCheckoutClicked,
  };
  return (
    <ModalContext.Provider value={modalCtx}>{children}</ModalContext.Provider>
  );
}
