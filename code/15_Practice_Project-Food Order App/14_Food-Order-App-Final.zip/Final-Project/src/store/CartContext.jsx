import { createContext, useState } from "react";

export const CartContext = createContext({
  items: [],
  addItemToCart: () => {},
  removeItemFromCart: () => {},
  clearCart: () => {},
});

export function CartContextProvider({ children }) {
  const [cartItems, setCartItems] = useState({
    items: [],
  });

  function addItemToCart(item) {
    console.log("Before adding Item to cart:", cartItems);
    setCartItems((prevItems) => {
      const existingItemIndex = prevItems.items.findIndex(
        (i) => i.item.id === item.id
      );
      if (existingItemIndex !== -1) {
        const updatedItems = [...prevItems.items];
        updatedItems[existingItemIndex].quantity += 1;
        return { items: updatedItems };
      }
      return { items: [...prevItems.items, { item, quantity: 1 }] };
    });
    console.log("Item added to cart:", cartItems);
  }

  function removeItemFromCart(id) {
    console.log("Before removing Item from cart:", cartItems);
    setCartItems((prevItems) => {
      const existingItemIndex = prevItems.items.findIndex(
        (i) => i.item.id === id
      );
      if (existingItemIndex !== -1) {
        const updatedItems = [...prevItems.items];
        updatedItems[existingItemIndex].quantity -= 1;
        if (updatedItems[existingItemIndex].quantity === 0) {
          updatedItems.splice(existingItemIndex, 1);
        }
        return { items: updatedItems };
      }
      return prevItems;
    });
  }

  function clearCart() {
    setCartItems({ items: [] });
  }

  const ctxValue = {
    items: cartItems.items,
    addItemToCart,
    removeItemFromCart,
    setCartItems,
    clearCart,
  };

  return (
    <CartContext.Provider value={ctxValue}>{children}</CartContext.Provider>
  );
}
