import { useState } from "react";

export default function useFetch(url) {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  async function fetchCall(request) {
    try {
      setIsLoading(true);
      console.log("isLoading data from:", isLoading);
      const response = await fetch(url, request);
      const data = await response.json();
      if (!response.ok) {
        setError(data.message || "Something went wrong");
      } else {
        setData(data);
      }
      setIsLoading(false);
      console.log("isLoading data from -1 :", isLoading);
    } catch (error) {
      setError(error.message || "Something went wrong");
      setIsLoading(false);
    }
  }

  //   useEffect(() => {
  //     fetchCall();
  //   }, [ params, url]);

  return {
    data,
    error,
    isLoading,
    fetchCall,
  };
}
