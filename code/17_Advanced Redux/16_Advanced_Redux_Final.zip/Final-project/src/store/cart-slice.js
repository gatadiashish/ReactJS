import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
  name: "cart",
  initialState: { items: [], isFirstLoad: true },
  reducers: {
    addItemToCart: (state, action) => {
      const existingItem = state.items.find(
        (item) => item.item.id === action.payload.id
      );
      if (existingItem) {
        existingItem.quantity++;
      } else {
        state.items.push({ item: action.payload, quantity: 1 });
      }
      state.isFirstLoad = false;
    },
    reduceQuantity: (state, action) => {
      const existingItem = state.items.find(
        (item) => item.item.id === action.payload.id
      );
      if (existingItem && existingItem.quantity === 1) {
        state.items = state.items.filter(
          (item) => item.item.id !== action.payload.id
        );
      } else {
        existingItem.quantity--;
      }
      state.isFirstLoad = false;
    },
    replaceCart: (state, action) => {
      state.items = action.payload;
    },
  },
});

export const cartActions = cartSlice.actions;

export default cartSlice;
