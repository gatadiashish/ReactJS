import { cartActions } from "./cart-slice";
import { uiActions } from "./ui-slice";

export const postCartData = (cartItems) => {
  return async (dispatch) => {
    dispatch(
      uiActions.showNotification({
        status: "pending",
        title: "Sending...",
        message: "Sending cart items...",
      })
    );
    const postData = async () => {
      const response = await fetch(
        "https://react-project-82e75-default-rtdb.asia-southeast1.firebasedatabase.app/cart.json",
        {
          method: "PUT",
          body: JSON.stringify(cartItems),
        }
      );

      if (!response.ok) {
        throw new Error("Could not fetch cart items!");
      }
      return response;
    };

    try {
      await postData();
    } catch (error) {
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error Sending...",
          message: "Sending cart items failed",
        })
      );
    }
    dispatch(
      uiActions.showNotification({
        status: "success",
        title: "SuccessFull",
        message: "SuccessFully sent cart items...",
      })
    );
  };
};

export const fetchCartData = () => {
  let fetchedItems = [];
  return async (dispatch) => {
    dispatch(
      uiActions.showNotification({
        status: "pending",
        title: "Fetching...",
        message: "Fetching cart items...",
      })
    );
    const getData = async () => {
      const responseData = await fetch(
        "https://react-project-82e75-default-rtdb.asia-southeast1.firebasedatabase.app/cart.json"
      );
      if (!responseData.ok) {
        throw new Error("Could not fetch cart items!");
      }
      return responseData;
    };
    try {
      const responseData = await getData();
      fetchedItems = await responseData.json();
    } catch (error) {
      dispatch(
        uiActions.showNotification({
          status: "error",
          title: "Error Fetching...",
          message: "Fetching cart items failed",
        })
      );
    }
    dispatch(
      uiActions.showNotification({
        status: "success",
        title: "SuccessFull",
        message: "SuccessFully fetched cart items...",
      })
    );
    dispatch(cartActions.replaceCart(fetchedItems));
  };
};
