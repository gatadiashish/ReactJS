import { configureStore } from "@reduxjs/toolkit";
import cartSlice from "./cart-slice";
import uiSlice from "./ui-slice";

// const initialCartState = {
//   items: [],
//   showCart: false,
// };

// const cartSlice = createSlice({
//   name: "cart",
//   initialState: initialCartState,
//   reducers: {
//     toggleCart: (state) => {
//       state.showCart = !state.showCart;
//     },
//     addItemToCart: (state, action) => {
//       const existingItem = state.items.find(
//         (item) => item.item.title === action.payload.title
//       );
//       if (existingItem) {
//         existingItem.quantity++;
//       } else {
//         state.items.push({ item: action.payload, quantity: 1 });
//       }
//     },
//     reduceQuantity: (state, action) => {
//       const existingItem = state.items.find(
//         (item) => item.item.title === action.payload.title
//       );
//       if (existingItem && existingItem.quantity === 1) {
//         state.items = state.items.filter(
//           (item) => item.item.title !== action.payload.title
//         );
//       } else {
//         existingItem.quantity--;
//       }
//     },
//   },
// });

const store = configureStore({
  reducer: {
    cart: cartSlice.reducer,
    ui: uiSlice.reducer,
  },
});

// export const cartActions = cartSlice.actions;
export default store;
