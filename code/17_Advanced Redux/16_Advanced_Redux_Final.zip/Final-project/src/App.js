import { useEffect } from "react";
import {
  useDispatch,
  useSelector,
} from "../node_modules/react-redux/dist/react-redux";
import Cart from "./components/Cart/Cart";
import Layout from "./components/Layout/Layout";
import Products from "./components/Shop/Products";
import Notification from "./components/UI/Notification";
import { fetchCartData, postCartData } from "./store/api-slice";

function App() {
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.items);
  const isFirstLoad = useSelector((state) => state.cart.isFirstLoad);
  const notification = useSelector((state) => state.ui.notification);

  useEffect(() => {
    if (!isFirstLoad) {
      dispatch(postCartData(cartItems));
    }
  }, [cartItems, dispatch, isFirstLoad]);

  useEffect(() => {
    if (cartItems.length === 0 && isFirstLoad) {
      dispatch(fetchCartData());
    }
  }, [dispatch, cartItems, isFirstLoad]);

  return (
    <>
      {notification && <Notification {...notification} />}
      <Layout>
        <Cart />
        <Products />
      </Layout>
    </>
  );
}

export default App;
