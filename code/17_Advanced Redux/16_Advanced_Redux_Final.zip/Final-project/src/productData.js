const productList = [
  {
    id: "p1",
    title: "Product 1",
    description: "This is a first product - amazing!",
    price: 19.99,
  },
  {
    id: "p2",
    title: "Product 2",
    description: "This is a second product - fantastic!",
    price: 29.99,
  },
  {
    id: "p3",
    title: "Product 3",
    description: "This is a third product - awesome!",
    price: 39.99,
  },
];

export default productList;
